// use this file for any theme specific javascript/jQuery
// e.g. if your css needs the interface to include extra tags then you can add them to your project from javascript in this file
